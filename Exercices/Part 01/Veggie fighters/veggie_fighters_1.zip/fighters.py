fighter_1 = {
        'name': 'Tomato',
        'punch': 3,
        'kick': 1,
        'bit': 4,
        'hp': 20,
        'defense': 1}

fighter_2 = {
        'name': 'Carrot',
        'punch': 2,
        'kick': 4,
        'bit': 3,
        'hp': 1,
        'defense': 2}