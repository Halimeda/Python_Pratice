from fighters import fighter_1, fighter_2
from random import choice


while fighter_1['hp'] > 0 and fighter_2['hp'] > 0:
    attack = choice(['punch', 'kick', 'bit'])
    attack_value = fighter_1[attack]
    attack_value = attack_value - fighter_2['defense']
    attack_value = max(attack_value, 0)
    fighter_2['hp'] = fighter_2['hp'] - attack_value

    print(fighter_1["name"] + " attack: " + attack + " - " + str(attack_value))

    attack = choice(['punch', 'kick', 'bit'])
    attack_value = fighter_2[attack]
    attack_value = attack_value - fighter_1['defense']
    attack_value = max(attack_value, 0)
    fighter_1['hp'] = fighter_1['hp'] - attack_value

    print(fighter_2["name"] + " attack: " + attack + " - " + str(attack_value))

if fighter_1['hp'] > 0:
    print(fighter_1["name"] + " wins!!!")
elif fighter_2['hp'] > 0:
    print(fighter_2["name"] + " wins!!!")
else:
    print("Double KO")